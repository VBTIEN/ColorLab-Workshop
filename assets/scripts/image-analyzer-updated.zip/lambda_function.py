import json
import boto3
import base64
from urllib.parse import unquote_plus
import uuid
from datetime import datetime

# Initialize AWS clients
rekognition = boto3.client('rekognition')
s3 = boto3.client('s3')
bedrock = boto3.client('bedrock-runtime')

def lambda_handler(event, context):
    """
    Lambda function để phân tích ảnh với Amazon Rekognition và Bedrock
    """
    
    # Add CORS headers
    headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    }
    
    try:
        # Handle OPTIONS request for CORS
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'CORS preflight'})
            }
        
        # Parse input
        if 'body' in event:
            # API Gateway request
            body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
            bucket = body.get('bucket', 'image-analyzer-workshop-1751722329')
            image_data = body.get('image_data')
            
            if not image_data:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'Missing image_data parameter'})
                }
            
            # Generate unique key for the image
            key = f"uploads/{datetime.now().strftime('%Y/%m/%d')}/{str(uuid.uuid4())}.jpg"
            
            # Upload image to S3
            try:
                image_bytes = base64.b64decode(image_data)
                s3.put_object(
                    Bucket=bucket,
                    Key=key,
                    Body=image_bytes,
                    ContentType='image/jpeg'
                )
                print(f"Image uploaded to s3://{bucket}/{key}")
            except Exception as e:
                print(f"Failed to upload image to S3: {str(e)}")
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({'error': f'Failed to upload image: {str(e)}'})
                }
                
        elif 'Records' in event:
            # S3 trigger
            bucket = event['Records'][0]['s3']['bucket']['name']
            key = unquote_plus(event['Records'][0]['s3']['object']['key'])
        else:
            # Direct invocation
            bucket = event.get('bucket')
            key = event.get('key')
            
        if not bucket or not key:
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': 'Missing bucket or key parameter'})
            }
        
        # Analyze image with Rekognition
        print(f"Analyzing image: s3://{bucket}/{key}")
        rekognition_results = analyze_with_rekognition(bucket, key)
        
        # Get advanced analysis with Bedrock
        bedrock_analysis = analyze_with_bedrock(bucket, key, rekognition_results)
        
        # Combine results
        analysis_result = {
            'image': f's3://{bucket}/{key}',
            'basic_analysis': rekognition_results,
            'advanced_analysis': bedrock_analysis,
            'timestamp': datetime.now().isoformat(),
            'request_id': context.aws_request_id
        }
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(analysis_result, indent=2)
        }
        
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': f'Error analyzing image: {str(e)}'})
        }

def analyze_with_rekognition(bucket, key):
    """Phân tích cơ bản với Amazon Rekognition"""
    
    results = {}
    
    try:
        # Detect labels (objects, scenes, activities)
        labels_response = rekognition.detect_labels(
            Image={'S3Object': {'Bucket': bucket, 'Name': key}},
            MaxLabels=20,
            MinConfidence=70
        )
        results['labels'] = [
            {
                'name': label['Name'],
                'confidence': round(label['Confidence'], 2),
                'categories': [cat['Name'] for cat in label.get('Categories', [])]
            }
            for label in labels_response['Labels']
        ]
        
        # Detect faces
        faces_response = rekognition.detect_faces(
            Image={'S3Object': {'Bucket': bucket, 'Name': key}},
            Attributes=['ALL']
        )
        results['faces'] = [
            {
                'age_range': face['AgeRange'],
                'gender': face['Gender']['Value'],
                'emotions': [
                    {
                        'type': emotion['Type'],
                        'confidence': round(emotion['Confidence'], 2)
                    }
                    for emotion in face['Emotions'][:3]  # Top 3 emotions
                ]
            }
            for face in faces_response['FaceDetails']
        ]
        
        # Detect text
        text_response = rekognition.detect_text(
            Image={'S3Object': {'Bucket': bucket, 'Name': key}}
        )
        results['text'] = [
            {
                'text': text['DetectedText'],
                'confidence': round(text['Confidence'], 2),
                'type': text['Type']
            }
            for text in text_response['TextDetections']
            if text['Type'] == 'LINE'  # Only get line-level text
        ]
        
    except Exception as e:
        results['error'] = f"Rekognition analysis failed: {str(e)}"
        print(f"Rekognition error: {str(e)}")
    
    return results

def analyze_with_bedrock(bucket, key, rekognition_data):
    """Phân tích nâng cao với Amazon Bedrock"""
    
    try:
        # Create prompt for advanced analysis
        prompt = create_analysis_prompt(rekognition_data)
        
        # Call Bedrock (using Claude model)
        response = bedrock.invoke_model(
            modelId='anthropic.claude-3-sonnet-20240229-v1:0',
            body=json.dumps({
                'anthropic_version': 'bedrock-2023-05-31',
                'max_tokens': 1000,
                'messages': [
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ]
            })
        )
        
        response_body = json.loads(response['body'].read())
        analysis = response_body['content'][0]['text']
        
        return {
            'artistic_analysis': analysis,
            'model_used': 'Claude-3-Sonnet'
        }
        
    except Exception as e:
        print(f"Bedrock error: {str(e)}")
        return {
            'error': f"Bedrock analysis failed: {str(e)}",
            'fallback_analysis': generate_fallback_analysis(rekognition_data)
        }

def create_analysis_prompt(rekognition_data):
    """Tạo prompt cho Bedrock dựa trên kết quả Rekognition"""
    
    labels = [label['name'] for label in rekognition_data.get('labels', [])]
    faces = rekognition_data.get('faces', [])
    text = [t['text'] for t in rekognition_data.get('text', [])]
    
    prompt = f"""
    Phân tích nghệ thuật và composition của bức ảnh dựa trên thông tin sau:
    
    Đối tượng trong ảnh: {', '.join(labels[:10])}
    Số người: {len(faces)}
    Văn bản: {', '.join(text) if text else 'Không có'}
    
    Hãy phân tích:
    1. Phong cách nghệ thuật và composition
    2. Tâm trạng và cảm xúc của bức ảnh
    3. Kỹ thuật chụp (nếu có thể đoán)
    4. Gợi ý cải thiện
    
    Trả lời bằng tiếng Việt, ngắn gọn và dễ hiểu.
    """
    
    return prompt

def generate_fallback_analysis(rekognition_data):
    """Tạo phân tích dự phòng khi Bedrock không khả dụng"""
    
    labels = rekognition_data.get('labels', [])
    faces = rekognition_data.get('faces', [])
    
    analysis = "Phân tích cơ bản:\n"
    
    if labels:
        main_subjects = [label['name'] for label in labels[:5]]
        analysis += f"- Chủ đề chính: {', '.join(main_subjects)}\n"
    
    if faces:
        analysis += f"- Có {len(faces)} người trong ảnh\n"
        emotions = []
        for face in faces:
            top_emotion = max(face.get('emotions', []), key=lambda x: x['confidence'])
            emotions.append(top_emotion['type'])
        if emotions:
            analysis += f"- Cảm xúc chủ đạo: {', '.join(set(emotions))}\n"
    
    return analysis
